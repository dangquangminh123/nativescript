# CleanWeather

This app was cloned from this beautiful [Behance design](https://mir-s3-cdn-cf.behance.net/project_modules/disp/011ad422645245.5631618fd6daf.gif). Please use your own Forecast.io API key if you want to fork it and enhance it. Read more on how to build this app yourself in the [Snacklab](http://snacklabs.nativescriptsnacks.com/snacklabs/vue-weather/#0).

I used Vue.js and NativeScript to create this app.

![screenshot](cleanweather.png)
